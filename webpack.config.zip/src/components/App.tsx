import React from "react";
import { MainPage } from "../pages/Main/Main";

const App: React.FC = () => {
	return (
		<div>
			<MainPage testProp="test" />
		</div>
	);
};

export default App;
